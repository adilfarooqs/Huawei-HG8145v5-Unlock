                       Set wshShell = wscript.CreateObject("WScript.Shell")
wshShell.Run "cmd.exe"

wscript.sleep 600
wshshell.sendkeys "telnet 192.168.1.1"
wshshell.sendkeys "{enter}"

wscript.sleep 600
wshshell.sendkeys "root"
wshshell.sendkeys "{enter}"
wscript.sleep 600
wshshell.sendkeys "adminHW"
wshshell.sendkeys "{enter}"

wscript.sleep 600
wshshell.sendkeys "su"
wshshell.sendkeys "{enter}"
wscript.sleep 600
wshshell.sendkeys "shell"
wshshell.sendkeys "{enter}"

wscript.sleep 600
wshshell.sendkeys "sudo restorehwmode.sh"
wshshell.sendkeys "{enter}"

WScript.Sleep 300
wshshell.sendkeys "reboot"
wshshell.sendkeys "{enter}"


